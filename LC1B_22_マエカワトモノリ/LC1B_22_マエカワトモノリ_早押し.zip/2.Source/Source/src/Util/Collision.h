#pragma once
#include "src/Entity/Entity.h"

namespace Collision{
    bool isHitSphere(Entity* e, const Entity* other);

};

